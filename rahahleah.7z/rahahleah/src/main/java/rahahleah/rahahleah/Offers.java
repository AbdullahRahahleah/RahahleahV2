
package rahahleah.rahahleah;
import java.util.ArrayList;

public class Offers {
	private ArrayList<hotel> Hotel;
	public ArrayList<hotel> getHotel() {
		return Hotel;
	}

	public void setHotel(ArrayList<hotel> hotel) {
		Hotel = hotel;
	}


	public Offers() {
	}
}